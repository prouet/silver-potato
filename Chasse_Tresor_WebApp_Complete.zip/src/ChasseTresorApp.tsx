
// Web app PWA pour chasse au trésor interactive
// Version féerique avec icônes, ambiance et visuel décoratif

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Sparkles } from "lucide-react";

const enigmes = [
  { titre: "Étape 1", texte: "J'ai quatre jambes, et je ne bouge pas. Je suis souvent près d'une table.", icone: "🪑" },
  { titre: "Étape 2", texte: "Je suis le roi du jardin, toujours vert, je donne de l'ombre et des fruits en été.", icone: "🌳" },
  { titre: "Étape 3", texte: "Je suis en terre, mais je n'ai pas de racines. Je suis dur comme la pierre et souvent plein de vies.", icone: "🪨" },
  { titre: "Étape 4", texte: "Je fais de grands bonds, je monte et je descends. Accroché à deux cordes, je fais rire les enfants.", icone: "🎠" },
  { titre: "Étape 5", texte: "Je suis tout droit, haut dans les airs. On me lance une balle et je l'avale si elle est bien visée.", icone: "🏀" },
  { titre: "Étape 6", texte: "Je glisse sans bouger, on grimpe pour me dompter. Je suis rouge, vert ou jaune, et je fais toujours rigoler.", icone: "🛝" },
  { titre: "Étape 7", texte: "Je ne suis pas une maison, mais on y range plein de choses. Parfois fermée à clé, j'ai souvent une vieille odeur de bois.", icone: "🏚️" }
];

export default function ChasseTresorApp() {
  const [etapesValidees, setEtapesValidees] = useState<number[]>([]);

  useEffect(() => {
    const audio = new Audio("/sounds/fantasy-forest.mp3");
    audio.loop = true;
    audio.volume = 0.3;
    audio.play().catch(() => {});
    return () => audio.pause();
  }, []);

  const toggleValidation = (index: number) => {
    setEtapesValidees((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const progress = Math.round((etapesValidees.length / enigmes.length) * 100);

  return (
    <div
      className="p-4 space-y-6 min-h-screen bg-cover bg-center"
      style={{ backgroundImage: "url('/images/carte-enchantee.jpg')" }}
    >
      <div className="backdrop-blur-md bg-white/80 rounded-3xl p-6 shadow-2xl border border-purple-300">
        <h1 className="text-3xl font-bold text-center text-purple-700 drop-shadow-sm">
          ✨ La mission magique de Teha, Elena et Maïana ✨
        </h1>
        <Progress value={progress} className="my-6" />

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {enigmes.map((enigme, index) => (
            <Card key={index} className="bg-white/90 shadow-lg rounded-2xl border border-purple-100">
              <CardContent className="p-4 space-y-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full justify-start text-left text-lg">
                      {enigme.icone} {enigme.titre} {etapesValidees.includes(index) ? "✅" : ""}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <p className="text-xl font-semibold text-purple-800">{enigme.icone} {enigme.titre}</p>
                    <p className="text-md py-2">{enigme.texte}</p>
                    <Button onClick={() => toggleValidation(index)} className="mt-4">
                      {etapesValidees.includes(index) ? "Marquer comme non trouvée" : "J'ai trouvé !"}
                    </Button>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          ))}
        </div>

        {progress === 100 && (
          <div className="text-center text-green-700 font-bold text-2xl mt-8 animate-bounce flex flex-col items-center gap-3">
            <Sparkles className="w-6 h-6" />
            <p>Bravo ! Tu as trouvé toutes les étapes et atteint le trésor final !</p>
            <p className="text-lg text-purple-800">Le trésor est caché dans la dépendance... 🏚️</p>
            <Sparkles className="w-6 h-6" />
          </div>
        )}
      </div>
    </div>
  );
}
