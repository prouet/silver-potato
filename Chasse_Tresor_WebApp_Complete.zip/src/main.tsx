import React from "react";
import ReactDOM from "react-dom/client";
import ChasseTresorApp from "./ChasseTresorApp";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ChasseTresorApp />
  </React.StrictMode>
);